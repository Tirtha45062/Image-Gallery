export class GlobalVariable {
    public static gallery_id: any=''; //Gallery Id
}