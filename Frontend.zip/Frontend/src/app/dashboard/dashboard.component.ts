import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { FolderService } from '../service/folder.service';
import { GlobalVariable } from '../global/global.variables';
import { AccountService } from '../service/account.service';
import { ImageService } from '../service/image.service';
import { FilterService } from '../service/filter.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private fservice: FolderService,
    private ACService: AccountService,
    private imgService: ImageService,
    private filter: FilterService
  ) {}

  folderArray: any = [];
  accountArray: any = [];
  randomImage: any = [];
  allImageArray: any = [];

  largeimg: any;
  title: any;

  folderForm = this.fb.group({
    name: ['', Validators.required],
  });
  ngOnInit() {
    this.getFolders();
    this.getAccounts();
    this.getAllImage();
  }

  onSubmit() {
    this.createFolder(this.folderForm.value);
  }

  getFolders() {
    this.folderArray = [];
    this.fservice.getFolders().subscribe(
      (res) => {
        this.folderArray = res.body;
        this.getimages();
      },
      (err) => {
        console.log(err);
      }
    );
  }

  getimages() {
    for (let i = 0; i < this.folderArray.length; i++) {
      const data = new FormData();
      data.append('gallery_id', this.folderArray[i].id);
      this.imgService.getImages(data).subscribe((res) => {
        var randomNumber = Math.floor(Math.random() * res.body.length);
        var randomImg = res.body[randomNumber].imagePath;
        this.randomImage[i] = randomImg;
        //console.log(this.randomImage);
      });
    }
  }

  createFolder(data: any) {
    let ref = document.getElementById('close');
    ref?.click();
    this.fservice.createFolder(data).subscribe(
      (res) => {
        this.getFolders();
        // console.log(res);
      },
      (err) => {
        console.log(err);
      }
    );
  }

  getAllPhoto(id: any) {
    window.localStorage.removeItem('folder_id');
    GlobalVariable.gallery_id = id;
    console.log(id);
    this.router.navigate(['/gallery/image']);
  }

  getAccounts() {
    this.ACService.getAccounts().subscribe(
      (res) => {
        this.accountArray = res.body;
        //console.log(res);
      },
      (err) => {
        console.log(err);
      }
    );
  }

  getAllImage() {
    this.fservice.getAllImage().subscribe(
      (res) => {
        this.allImageArray = res.body;
        // console.log(res.body);
      },
      (err) => {
        console.log(err);
      }
    );
  }

  largeimage(url: any, title: any) {
    this.largeimg = url;
    this.title = title;
  }
}
